"""
Yargıtay Karar Arama (karararama.yargitay.gov.tr) Veri Toplama ve Temizleme Aracı
====================================================================================
UYAP 2.0 Prosedürel Uyum Muhafızı - Bitirme Tezi Ek Materyali
Amaç: Kamuya açık Yargıtay kararlarını indirip, model ince ayarı için
      temiz bir CSV/JSONL veri setine dönüştürmek.

ÖNEMLİ: Bu script yalnızca kamuya açık arama arayüzünü kullanır.
Gerçek UYAP çekirdek sistemine hiçbir erişim yapılmaz.
Yargıtay sitesinin kullanım şartlarına (robots.txt, hız sınırı) uyulmalıdır.

Kurulum:
    pip install requests beautifulsoup4 pandas tqdm --break-system-packages
"""

import re
import json
import time
import logging
from pathlib import Path
from dataclasses import dataclass, asdict

import requests
from bs4 import BeautifulSoup
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("yargitay_scraper")

BASE_SEARCH_URL = "https://karararama.yargitay.gov.tr/aramadetaylist"
BASE_DETAIL_URL = "https://karararama.yargitay.gov.tr/aramadetay"
REQUEST_DELAY_SECONDS = 2.0   # Sunucuya nazik davran: dakikada ~30 istek
TIMEOUT = 20

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
}


@dataclass
class KararKaydi:
    karar_id: str
    daire: str
    esas_no: str
    karar_no: str
    karar_tarihi: str
    metin_ham: str
    metin_temiz: str = ""
    kelime_sayisi: int = 0


def temizle_metin(ham_metin: str) -> str:
    """
    Ham HTML/metin içeriğini model eğitimi için temizler:
    - HTML etiketlerini kaldırır
    - Fazla boşluk/satır sonlarını normalize eder
    - Standart üst bilgi kalıplarını (T.C. YARGITAY ... vb.) korur ama
      tekrarlayan gürültüyü (sayfa numarası, imza bloğu placeholder) siler
    """
    if not ham_metin:
        return ""

    soup = BeautifulSoup(ham_metin, "html.parser")
    metin = soup.get_text(separator="\n")

    # Çoklu boşluk / satır sonu normalize
    metin = re.sub(r"[ \t]+", " ", metin)
    metin = re.sub(r"\n{3,}", "\n\n", metin)

    # Sık görülen gürültü kalıpları (sayfa altbilgisi, imza yer tutucu vb.)
    gurultu_kaliplari = [
        r"\(\s*\.\.\.\s*\)",           # (...) placeholder
        r"^\s*Sayfa\s*\d+\s*/\s*\d+\s*$",  # "Sayfa 3/12"
        r"^-{3,}$",                     # ayraç çizgileri
    ]
    for kalip in gurultu_kaliplari:
        metin = re.sub(kalip, "", metin, flags=re.MULTILINE)

    return metin.strip()


def karar_kimlik_bilgisi_cikar(metin: str) -> dict:
    """Esas No / Karar No / Tarih gibi alanları regex ile ayıklar."""
    esas = re.search(r"Esas\s*No\s*[:\-]?\s*([\d/]+)", metin)
    karar = re.search(r"Karar\s*No\s*[:\-]?\s*([\d/]+)", metin)
    tarih = re.search(r"Karar\s*Tarihi\s*[:\-]?\s*([\d.\/]+)", metin)
    return {
        "esas_no": esas.group(1) if esas else "",
        "karar_no": karar.group(1) if karar else "",
        "karar_tarihi": tarih.group(1) if tarih else "",
    }


def arama_sorgusu_gonder(anahtar_kelime: str, daire: str = "", sayfa: int = 1) -> list[dict]:
    """
    Tek bir arama sayfası için sonuç listesini döndürür.
    NOT: Gerçek API şeması zaman içinde değişebilir; bu fonksiyon site
    yapısına göre güncellenmelidir (buradaki payload alanları örnek amaçlıdır).
    """
    payload = {
        "aranan": anahtar_kelime,
        "daire": daire,
        "pageSize": 20,
        "pageNumber": sayfa,
    }
    try:
        resp = requests.post(BASE_SEARCH_URL, json=payload, headers=HEADERS, timeout=TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        return data.get("data", [])
    except requests.RequestException as e:
        logger.warning(f"Arama isteği başarısız (sayfa {sayfa}): {e}")
        return []
    except json.JSONDecodeError:
        logger.warning(f"JSON parse hatası (sayfa {sayfa}) - site yapısı değişmiş olabilir")
        return []


def karar_detayi_getir(karar_id: str) -> str:
    """Tek bir kararın tam metnini getirir."""
    try:
        resp = requests.get(f"{BASE_DETAIL_URL}/{karar_id}", headers=HEADERS, timeout=TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        return data.get("content", "") or data.get("metin", "")
    except (requests.RequestException, json.JSONDecodeError) as e:
        logger.warning(f"Detay getirilemedi (id={karar_id}): {e}")
        return ""


def toplu_veri_topla(
    anahtar_kelimeler: list[str],
    hedef_karar_sayisi: int = 1000,
    cikti_dosyasi: str = "yargitay_kararlari.jsonl",
) -> None:
    """
    Ana toplama döngüsü: birden çok anahtar kelime için arama yapar,
    her kararın detayını çeker, temizler ve JSONL olarak diske yazar.

    Tez önerisindeki pilot yol haritasına uygun varsayılan hedef: 500-1000 karar.
    """
    toplanan: list[KararKaydi] = []
    cikti_yolu = Path(cikti_dosyasi)

    with cikti_yolu.open("w", encoding="utf-8") as f:
        for kelime in anahtar_kelimeler:
            logger.info(f"Anahtar kelime: '{kelime}' için arama başlıyor...")
            sayfa = 1
            while len(toplanan) < hedef_karar_sayisi:
                sonuclar = arama_sorgusu_gonder(kelime, sayfa=sayfa)
                if not sonuclar:
                    break

                for kayit in tqdm(sonuclar, desc=f"{kelime} - sayfa {sayfa}"):
                    karar_id = str(kayit.get("id", ""))
                    if not karar_id:
                        continue

                    time.sleep(REQUEST_DELAY_SECONDS)
                    ham_metin = karar_detayi_getir(karar_id)
                    if not ham_metin:
                        continue

                    temiz = temizle_metin(ham_metin)
                    if len(temiz.split()) < 50:
                        continue  # çok kısa/hatalı kayıtları ele

                    kimlik = karar_kimlik_bilgisi_cikar(temiz)
                    kayit_obj = KararKaydi(
                        karar_id=karar_id,
                        daire=kayit.get("daire", ""),
                        esas_no=kimlik["esas_no"],
                        karar_no=kimlik["karar_no"],
                        karar_tarihi=kimlik["karar_tarihi"],
                        metin_ham=ham_metin[:500],  # denetim için kısaltılmış ham örnek
                        metin_temiz=temiz,
                        kelime_sayisi=len(temiz.split()),
                    )
                    toplanan.append(kayit_obj)
                    f.write(json.dumps(asdict(kayit_obj), ensure_ascii=False) + "\n")

                    if len(toplanan) >= hedef_karar_sayisi:
                        break

                sayfa += 1
                time.sleep(REQUEST_DELAY_SECONDS)

    logger.info(f"Toplam {len(toplanan)} karar toplandı -> {cikti_yolu}")

    # Hızlı özet istatistik (tez Bölüm 9'daki metodoloji ekine referans için)
    if toplanan:
        df = pd.DataFrame([asdict(k) for k in toplanan])
        logger.info(f"Ortalama kelime sayısı: {df['kelime_sayisi'].mean():.0f}")
        logger.info(f"Daire dağılımı:\n{df['daire'].value_counts()}")


def etiketleme_sablonu_olustur(
    jsonl_dosyasi: str = "yargitay_kararlari.jsonl",
    ornek_sayisi: int = 200,
    cikti_dosyasi: str = "etiketleme_sablonu.csv",
) -> None:
    """
    Elle etiketleme için rastgele örneklem çıkarır ve boş etiket
    sütunlarıyla bir CSV üretir (tez yol haritası adım 2).

    Etiket şeması önerisi (tez Bölüm 8 ile uyumlu):
        prosedur_uygun: {0, 1}           - prosedürel uygunluk
        risk_kategorisi: {düşük, orta, yüksek}
        aciklama: serbest metin (etiketleyici notu)
    """
    kayitlar = []
    with open(jsonl_dosyasi, encoding="utf-8") as f:
        for satir in f:
            kayitlar.append(json.loads(satir))

    df = pd.DataFrame(kayitlar)
    ornek = df.sample(n=min(ornek_sayisi, len(df)), random_state=42)

    ornek["prosedur_uygun"] = ""
    ornek["risk_kategorisi"] = ""
    ornek["aciklama"] = ""

    ornek[["karar_id", "daire", "esas_no", "karar_no", "metin_temiz",
           "prosedur_uygun", "risk_kategorisi", "aciklama"]].to_csv(
        cikti_dosyasi, index=False, encoding="utf-8-sig"
    )
    logger.info(f"{len(ornek)} kayıtlık etiketleme şablonu oluşturuldu -> {cikti_dosyasi}")


if __name__ == "__main__":
    # Örnek kullanım - tez yol haritası Adım 1-2
    ANAHTAR_KELIMELER = [
        "tebligat usulüne aykırılık",
        "süre aşımı",
        "yetkisizlik kararı",
        "görevsizlik kararı",
        "hukuki dinlenilme hakkı",
    ]

    toplu_veri_topla(
        anahtar_kelimeler=ANAHTAR_KELIMELER,
        hedef_karar_sayisi=1000,
        cikti_dosyasi="yargitay_kararlari.jsonl",
    )

    etiketleme_sablonu_olustur(
        jsonl_dosyasi="yargitay_kararlari.jsonl",
        ornek_sayisi=200,
        cikti_dosyasi="etiketleme_sablonu.csv",
    )
